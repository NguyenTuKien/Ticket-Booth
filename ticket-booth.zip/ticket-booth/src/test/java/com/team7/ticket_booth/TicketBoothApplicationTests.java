package com.team7.ticket_booth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketBoothApplicationTests {

	@Test
	void contextLoads() {
	}

}
