package com.team7.ticket_booth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketBoothApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketBoothApplication.class, args);
	}

}
